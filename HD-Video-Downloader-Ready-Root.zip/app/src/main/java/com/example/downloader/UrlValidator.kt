package com.example.downloader

import android.net.Uri
import com.example.model.PlatformType
import com.example.model.VideoAnalysis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class UrlValidator(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {

    suspend fun analyzeUrl(rawUrl: String): VideoAnalysis = withContext(Dispatchers.IO) {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty() || (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true))) {
            return@withContext VideoAnalysis(
                url = trimmed,
                platform = PlatformType.UNSUPPORTED,
                isValid = false,
                title = "Invalid URL",
                suggestedFileName = "video.mp4",
                isDownloadAuthorized = false,
                complianceNoticeTitle = "Invalid URL format",
                complianceNoticeBody = "Please enter a valid link starting with http:// or https://"
            )
        }

        val uri = try {
            Uri.parse(trimmed)
        } catch (_: Exception) {
            null
        }

        val host = uri?.host?.lowercase() ?: ""

        // Check YouTube
        if (host == "youtube.com" || host.endsWith(".youtube.com") || host == "youtu.be") {
            return@withContext VideoAnalysis(
                url = trimmed,
                platform = PlatformType.YOUTUBE,
                isValid = true,
                title = extractYoutubeTitle(trimmed),
                suggestedFileName = "youtube_video.mp4",
                qualityLabel = "YouTube Stream (Protected)",
                isDownloadAuthorized = false,
                complianceNoticeTitle = "YouTube Terms of Service Notice",
                complianceNoticeBody = "Downloading content from YouTube is restricted under YouTube Terms of Service and DRM copyright policies. In strict compliance with official Google and YouTube guidelines, unauthorized downloads are not permitted. You can open and watch this video on YouTube.",
                canOpenInExternalApp = true,
                externalAppUri = trimmed
            )
        }

        // Check Instagram
        if (host == "instagram.com" || host.endsWith(".instagram.com")) {
            return@withContext VideoAnalysis(
                url = trimmed,
                platform = PlatformType.INSTAGRAM,
                isValid = true,
                title = "Instagram Media",
                suggestedFileName = "instagram_video.mp4",
                qualityLabel = "Instagram Stream (Protected)",
                isDownloadAuthorized = false,
                complianceNoticeTitle = "Instagram Content Notice",
                complianceNoticeBody = "Instagram restricts direct media downloading without authorized API credentials and content creator consent. To respect copyright and privacy rules, unauthorized extraction is disabled. You can open this post on Instagram.",
                canOpenInExternalApp = true,
                externalAppUri = trimmed
            )
        }

        // Check direct video link or probe URL with HEAD request
        val cleanPath = uri?.path?.lowercase() ?: ""
        val hasVideoExtension = cleanPath.endsWith(".mp4") ||
                cleanPath.endsWith(".webm") ||
                cleanPath.endsWith(".mov") ||
                cleanPath.endsWith(".m4v") ||
                cleanPath.endsWith(".mkv") ||
                cleanPath.endsWith(".3gp")

        var probeContentLength = 0L
        var probeContentType = "video/mp4"
        var finalUrl = trimmed
        var isLiveStream = false

        try {
            val request = Request.Builder()
                .url(trimmed)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:109.0)")
                .head()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    finalUrl = response.request.url.toString()
                    probeContentLength = response.header("Content-Length")?.toLongOrNull() ?: 0L
                    probeContentType = response.header("Content-Type") ?: if (hasVideoExtension) "video/mp4" else ""
                }
            }
        } catch (_: Exception) {
            // Head might fail on some CDNs, proceed with URL heuristics
        }

        val isVideoMime = probeContentType.startsWith("video/", ignoreCase = true) ||
                probeContentType.contains("application/octet-stream", ignoreCase = true) ||
                hasVideoExtension

        if (!isVideoMime && !hasVideoExtension) {
            return@withContext VideoAnalysis(
                url = trimmed,
                platform = PlatformType.UNSUPPORTED,
                isValid = false,
                title = "Unsupported Stream",
                suggestedFileName = "video.mp4",
                isDownloadAuthorized = false,
                complianceNoticeTitle = "Non-Video URL",
                complianceNoticeBody = "No downloadable direct video stream was detected at this URL. Make sure it points directly to an MP4, WebM, MOV, or M4V media file."
            )
        }

        // Genuine video quality resolution detection
        val quality = detectGenuineQuality(trimmed, cleanPath, probeContentLength)
        val extractedFileName = deriveFileName(trimmed, cleanPath, probeContentType)
        val cleanTitle = deriveTitle(extractedFileName)

        VideoAnalysis(
            url = finalUrl,
            platform = PlatformType.DIRECT,
            isValid = true,
            title = cleanTitle,
            suggestedFileName = extractedFileName,
            fileSizeBytes = probeContentLength,
            mimeType = if (probeContentType.isNotBlank()) probeContentType else "video/mp4",
            qualityLabel = quality,
            isDownloadAuthorized = true
        )
    }

    private fun detectGenuineQuality(url: String, path: String, contentLength: Long): String {
        val lower = "$url $path".lowercase()
        return when {
            lower.contains("4k") || lower.contains("2160p") -> "4K UHD"
            lower.contains("1080p") || lower.contains("fhd") -> "1080p FHD"
            lower.contains("720p") || lower.contains("hd") -> "720p HD"
            lower.contains("480p") -> "480p SD"
            lower.contains("360p") -> "360p"
            contentLength > 120_000_000L -> "1080p Source"
            contentLength > 30_000_000L -> "720p Source"
            contentLength > 8_000_000L -> "480p Source"
            contentLength > 0L -> "Original Source"
            else -> "Original Stream"
        }
    }

    private fun deriveFileName(url: String, path: String, contentType: String): String {
        val lastSegment = path.substringAfterLast('/', "")
        if (lastSegment.isNotBlank() && (lastSegment.contains(".mp4") || lastSegment.contains(".webm") || lastSegment.contains(".mov"))) {
            return lastSegment.take(60)
        }
        val ext = when {
            contentType.contains("webm") -> ".webm"
            contentType.contains("quicktime") || contentType.contains("mov") -> ".mov"
            contentType.contains("m4v") -> ".m4v"
            else -> ".mp4"
        }
        val timestamp = System.currentTimeMillis() % 100000
        return "HD_Video_$timestamp$ext"
    }

    private fun deriveTitle(fileName: String): String {
        val nameWithoutExt = fileName.substringBeforeLast('.')
            .replace('_', ' ')
            .replace('-', ' ')
            .trim()
        return if (nameWithoutExt.isNotBlank()) {
            nameWithoutExt.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        } else {
            "HD Video"
        }
    }

    private fun extractYoutubeTitle(url: String): String {
        return "YouTube Video Stream"
    }
}
