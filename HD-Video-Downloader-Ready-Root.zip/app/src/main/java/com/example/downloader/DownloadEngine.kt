package com.example.downloader

import android.app.DownloadManager
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import com.example.model.DownloadStatus
import com.example.model.VideoAnalysis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ActiveDownloadState(
    val entityId: Long = 0L,
    val downloadManagerId: Long = 0L,
    val title: String = "",
    val fileName: String = "",
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val progress: Int = 0,
    val speedBytesPerSec: Long = 0L,
    val status: DownloadStatus = DownloadStatus.DOWNLOADING
)

class DownloadEngine(
    private val context: Context,
    private val downloadDao: DownloadDao,
    private val scope: CoroutineScope
) {
    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private var monitorJob: Job? = null

    private val _activeDownload = MutableStateFlow<ActiveDownloadState?>(null)
    val activeDownload: StateFlow<ActiveDownloadState?> = _activeDownload.asStateFlow()

    private var lastBytes = 0L
    private var lastTimeMs = 0L

    init {
        startActiveMonitoring()
    }

    suspend fun startDownload(
        analysis: VideoAnalysis,
        wifiOnly: Boolean = false,
        showNotifications: Boolean = true
    ): Long = withContext(Dispatchers.IO) {
        val destinationFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!destinationFolder.exists()) {
            destinationFolder.mkdirs()
        }

        // Sanitize filename to avoid duplicates
        var targetFile = File(destinationFolder, analysis.suggestedFileName)
        var fileName = analysis.suggestedFileName
        if (targetFile.exists()) {
            val nameOnly = analysis.suggestedFileName.substringBeforeLast('.')
            val ext = analysis.suggestedFileName.substringAfterLast('.', "mp4")
            fileName = "${nameOnly}_${System.currentTimeMillis() % 10000}.$ext"
            targetFile = File(destinationFolder, fileName)
        }

        val request = DownloadManager.Request(Uri.parse(analysis.url)).apply {
            setTitle(analysis.title)
            setDescription("Downloading video in high quality")
            setMimeType(analysis.mimeType)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            setNotificationVisibility(
                if (showNotifications) {
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                } else {
                    DownloadManager.Request.VISIBILITY_HIDDEN
                }
            )
            val networkTypes = if (wifiOnly) {
                DownloadManager.Request.NETWORK_WIFI
            } else {
                DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE
            }
            setAllowedNetworkTypes(networkTypes)
            setAllowedOverRoaming(true)
        }

        val dmId = downloadManager.enqueue(request)

        val entity = DownloadEntity(
            downloadManagerId = dmId,
            url = analysis.url,
            title = analysis.title,
            fileName = fileName,
            filePath = targetFile.absolutePath,
            fileUri = Uri.fromFile(targetFile).toString(),
            mimeType = analysis.mimeType,
            fileSizeBytes = analysis.fileSizeBytes,
            bytesDownloaded = 0L,
            progress = 0,
            speedBytesPerSec = 0L,
            qualityLabel = analysis.qualityLabel,
            status = DownloadStatus.DOWNLOADING
        )

        val entityId = downloadDao.insertDownload(entity)

        lastBytes = 0L
        lastTimeMs = System.currentTimeMillis()

        _activeDownload.value = ActiveDownloadState(
            entityId = entityId,
            downloadManagerId = dmId,
            title = analysis.title,
            fileName = fileName,
            bytesDownloaded = 0L,
            totalBytes = analysis.fileSizeBytes,
            progress = 0,
            speedBytesPerSec = 0L,
            status = DownloadStatus.DOWNLOADING
        )

        startActiveMonitoring()
        entityId
    }

    private fun startActiveMonitoring() {
        if (monitorJob?.isActive == true) return

        monitorJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val current = _activeDownload.value
                if (current != null && (current.status == DownloadStatus.DOWNLOADING || current.status == DownloadStatus.PENDING || current.status == DownloadStatus.PAUSED)) {
                    pollDownloadManager(current)
                } else {
                    // Check if there are active downloads in DB
                    val dbEntity = downloadDao.getDownloadByDmId(current?.downloadManagerId ?: -1L)
                    if (dbEntity == null || dbEntity.status == DownloadStatus.COMPLETED || dbEntity.status == DownloadStatus.FAILED) {
                        // Sleep slightly longer when idle
                        delay(1200)
                        continue
                    }
                }
                delay(650)
            }
        }
    }

    private suspend fun pollDownloadManager(current: ActiveDownloadState) {
        val query = DownloadManager.Query().setFilterById(current.downloadManagerId)
        val cursor: Cursor? = try {
            downloadManager.query(query)
        } catch (_: Exception) {
            null
        }

        cursor?.use {
            if (it.moveToFirst()) {
                val bytesCol = it.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val totalCol = it.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val statusCol = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val reasonCol = it.getColumnIndex(DownloadManager.COLUMN_REASON)
                val localUriCol = it.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)

                val downloaded = if (bytesCol != -1) it.getLong(bytesCol) else 0L
                val total = if (totalCol != -1) it.getLong(totalCol) else 0L
                val dmStatus = if (statusCol != -1) it.getInt(statusCol) else -1
                val localUri = if (localUriCol != -1) it.getString(localUriCol) ?: "" else ""

                val now = System.currentTimeMillis()
                val deltaMs = (now - lastTimeMs).coerceAtLeast(1)
                val deltaBytes = (downloaded - lastBytes).coerceAtLeast(0)
                val speed = if (deltaMs > 0) (deltaBytes * 1000L) / deltaMs else 0L

                lastBytes = downloaded
                lastTimeMs = now

                val progress = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else current.progress

                val resolvedStatus = when (dmStatus) {
                    DownloadManager.STATUS_RUNNING -> DownloadStatus.DOWNLOADING
                    DownloadManager.STATUS_PAUSED -> DownloadStatus.PAUSED
                    DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.COMPLETED
                    DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                    DownloadManager.STATUS_PENDING -> DownloadStatus.PENDING
                    else -> current.status
                }

                _activeDownload.value = current.copy(
                    bytesDownloaded = downloaded,
                    totalBytes = if (total > 0) total else current.totalBytes,
                    progress = progress,
                    speedBytesPerSec = speed,
                    status = resolvedStatus
                )

                // Update database
                val entity = downloadDao.getDownloadById(current.entityId)
                if (entity != null) {
                    var updated = entity.copy(
                        bytesDownloaded = downloaded,
                        fileSizeBytes = if (total > 0) total else entity.fileSizeBytes,
                        progress = progress,
                        speedBytesPerSec = speed,
                        status = resolvedStatus
                    )
                    if (localUri.isNotBlank()) {
                        updated = updated.copy(fileUri = localUri)
                    }
                    if (resolvedStatus == DownloadStatus.FAILED && reasonCol != -1) {
                        val reason = it.getInt(reasonCol)
                        updated = updated.copy(errorMessage = "Download error code: $reason")
                    }
                    downloadDao.updateDownload(updated)
                }

                if (resolvedStatus == DownloadStatus.COMPLETED || resolvedStatus == DownloadStatus.FAILED) {
                    delay(2000)
                    if (_activeDownload.value?.entityId == current.entityId) {
                        _activeDownload.value = null
                    }
                }
            }
        }
    }

    suspend fun cancelDownload(entityId: Long, dmId: Long) = withContext(Dispatchers.IO) {
        try {
            downloadManager.remove(dmId)
        } catch (_: Exception) {}

        val entity = downloadDao.getDownloadById(entityId)
        if (entity != null) {
            downloadDao.updateDownload(entity.copy(status = DownloadStatus.CANCELED))
        }

        if (_activeDownload.value?.entityId == entityId) {
            _activeDownload.value = null
        }
    }

    suspend fun deleteDownload(entity: DownloadEntity) = withContext(Dispatchers.IO) {
        if (entity.downloadManagerId > 0) {
            try {
                downloadManager.remove(entity.downloadManagerId)
            } catch (_: Exception) {}
        }

        if (entity.filePath.isNotBlank()) {
            val file = File(entity.filePath)
            if (file.exists()) {
                file.delete()
            }
        }

        downloadDao.deleteDownload(entity)
        if (_activeDownload.value?.entityId == entity.id) {
            _activeDownload.value = null
        }
    }
}
