package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.DownloadStatus

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val downloadManagerId: Long = -1L,
    val url: String,
    val title: String,
    val fileName: String,
    val fileUri: String = "",
    val filePath: String = "",
    val mimeType: String = "video/mp4",
    val fileSizeBytes: Long = 0L,
    val bytesDownloaded: Long = 0L,
    val progress: Int = 0,
    val speedBytesPerSec: Long = 0L,
    val qualityLabel: String = "HD",
    val status: DownloadStatus = DownloadStatus.PENDING,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
