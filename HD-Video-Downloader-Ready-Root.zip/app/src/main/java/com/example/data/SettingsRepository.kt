package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val wifiOnly: Boolean = false,
    val notifications: Boolean = true,
    val theme: String = "DARK", // "DARK", "LIGHT", "SYSTEM"
    val language: String = "en"  // "en", "hi"
)

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("app_settings_hd_downloader", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(
        AppSettings(
            wifiOnly = prefs.getBoolean("key_wifi_only", false),
            notifications = prefs.getBoolean("key_notifications", true),
            theme = prefs.getString("key_theme", "DARK") ?: "DARK",
            language = prefs.getString("key_language", "en") ?: "en"
        )
    )
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun setWifiOnly(enabled: Boolean) {
        prefs.edit().putBoolean("key_wifi_only", enabled).apply()
        _settings.value = _settings.value.copy(wifiOnly = enabled)
    }

    fun setNotifications(enabled: Boolean) {
        prefs.edit().putBoolean("key_notifications", enabled).apply()
        _settings.value = _settings.value.copy(notifications = enabled)
    }

    fun setTheme(theme: String) {
        prefs.edit().putString("key_theme", theme).apply()
        _settings.value = _settings.value.copy(theme = theme)
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString("key_language", lang).apply()
        _settings.value = _settings.value.copy(language = lang)
    }
}
