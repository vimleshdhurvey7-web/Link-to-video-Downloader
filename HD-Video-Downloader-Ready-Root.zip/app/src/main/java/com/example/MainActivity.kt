package com.example

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonSkyBlue
import com.example.viewmodel.AppTab
import com.example.viewmodel.MainViewModel
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle shared URL from other apps (browser, social apps, etc.)
        handleIncomingIntent(intent)

        setContent {
            val settings by viewModel.settings.collectAsState()
            val currentTab by viewModel.currentTab.collectAsState()
            val toastMessage by viewModel.toastMessage.collectAsState()

            // Toast effect
            LaunchedEffect(toastMessage) {
                toastMessage?.let {
                    Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            // Theme selection
            val isDark = when (settings.theme) {
                "LIGHT" -> false
                "SYSTEM" -> isSystemInDarkTheme()
                else -> true
            }

            // Locale localization
            val locale = Locale(settings.language)
            val config = Configuration(LocalConfiguration.current).apply {
                setLocale(locale)
            }
            val localizedContext = remember(settings.language) {
                createConfigurationContext(config)
            }

            CompositionLocalProvider(
                LocalConfiguration provides config,
                LocalContext provides localizedContext
            ) {
                MyApplicationTheme(darkTheme = isDark) {
                    val snackbarHostState = remember { SnackbarHostState() }

                    // Custom BackHandler: if on sub-tab, return to Downloader tab
                    BackHandler(enabled = currentTab != AppTab.DOWNLOADER) {
                        viewModel.setTab(AppTab.DOWNLOADER)
                    }

                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.safeDrawing),
                        bottomBar = {
                            MainBottomNavigation(
                                currentTab = currentTab,
                                onSelectTab = { viewModel.setTab(it) }
                            )
                        },
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        containerColor = MaterialTheme.colorScheme.background
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (currentTab) {
                                AppTab.DOWNLOADER -> HomeScreen(viewModel = viewModel)
                                AppTab.DOWNLOADS -> DownloadsScreen(viewModel = viewModel)
                                AppTab.PLAYER -> VideoPlayerScreen(viewModel = viewModel)
                                AppTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            if (sharedText.isNotBlank()) {
                viewModel.onUrlChanged(sharedText)
                viewModel.analyzeCurrentUrl()
                viewModel.setTab(AppTab.DOWNLOADER)
            }
        }
    }
}

@Composable
fun MainBottomNavigation(
    currentTab: AppTab,
    onSelectTab: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("main_bottom_nav_bar"),
        containerColor = MidnightNavy,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentTab == AppTab.DOWNLOADER,
            onClick = { onSelectTab(AppTab.DOWNLOADER) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AppTab.DOWNLOADER) Icons.Filled.Download else Icons.Outlined.Download,
                    contentDescription = stringResource(R.string.tab_downloader)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_downloader),
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = NeonSkyBlue,
                indicatorColor = ElectricBlue,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_downloader")
        )

        NavigationBarItem(
            selected = currentTab == AppTab.DOWNLOADS,
            onClick = { onSelectTab(AppTab.DOWNLOADS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AppTab.DOWNLOADS) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                    contentDescription = stringResource(R.string.tab_downloads)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_downloads),
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = NeonSkyBlue,
                indicatorColor = ElectricBlue,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_downloads")
        )

        NavigationBarItem(
            selected = currentTab == AppTab.PLAYER,
            onClick = { onSelectTab(AppTab.PLAYER) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AppTab.PLAYER) Icons.Filled.PlayCircle else Icons.Outlined.PlayCircle,
                    contentDescription = stringResource(R.string.tab_player)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_player),
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = NeonSkyBlue,
                indicatorColor = ElectricBlue,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_player")
        )

        NavigationBarItem(
            selected = currentTab == AppTab.SETTINGS,
            onClick = { onSelectTab(AppTab.SETTINGS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AppTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                    contentDescription = stringResource(R.string.tab_settings)
                )
            },
            label = {
                Text(
                    text = stringResource(R.string.tab_settings),
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = NeonSkyBlue,
                indicatorColor = ElectricBlue,
                unselectedIconColor = Color(0xFF94A3B8),
                unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_settings")
        )
    }
}
