package com.example.model

enum class DownloadStatus {
    PENDING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELED
}

enum class PlatformType {
    DIRECT,
    YOUTUBE,
    INSTAGRAM,
    UNSUPPORTED
}
