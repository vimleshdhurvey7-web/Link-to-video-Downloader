package com.example.model

data class VideoAnalysis(
    val url: String,
    val platform: PlatformType,
    val isValid: Boolean,
    val title: String,
    val suggestedFileName: String,
    val fileSizeBytes: Long = 0L,
    val mimeType: String = "video/mp4",
    val qualityLabel: String = "Original",
    val isDownloadAuthorized: Boolean = true,
    val complianceNoticeTitle: String? = null,
    val complianceNoticeBody: String? = null,
    val canOpenInExternalApp: Boolean = false,
    val externalAppUri: String? = null
)
