package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.PlatformType
import com.example.model.VideoAnalysis
import com.example.ui.theme.AccentWarning
import com.example.ui.theme.NeonSkyBlue
import com.example.ui.theme.SurfaceCardBorder

@Composable
fun ComplianceNoticeCard(
    analysis: VideoAnalysis,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isYouTube = analysis.platform == PlatformType.YOUTUBE
    val isInstagram = analysis.platform == PlatformType.INSTAGRAM

    val accentColor = if (isYouTube) Color(0xFFFF4E45) else if (isInstagram) Color(0xFFE1306C) else AccentWarning
    val title = analysis.complianceNoticeTitle ?: stringResource(R.string.compliance_title)
    val body = analysis.complianceNoticeBody ?: stringResource(R.string.compliance_desc)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF141E33))
            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .padding(16.dp)
            .testTag("compliance_notice_card")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isYouTube || isInstagram) Icons.Default.Shield else Icons.Default.Info,
                        contentDescription = "Policy Notice",
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = if (isYouTube) "YouTube API & DRM Policy" else if (isInstagram) "Instagram Content Protection" else "Policy Notice",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = accentColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp, lineHeight = 18.sp),
                color = Color(0xFFCBD5E1)
            )

            if (analysis.canOpenInExternalApp && !analysis.externalAppUri.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(analysis.externalAppUri))
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_external_app_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = NeonSkyBlue
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(SurfaceCardBorder)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open in app",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.open_in_browser),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
