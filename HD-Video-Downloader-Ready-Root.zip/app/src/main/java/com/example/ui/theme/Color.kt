package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Premium Midnight Blue & Obsidian Palette
val DeepObsidian = Color(0xFF070B14)
val MidnightNavy = Color(0xFF0B1324)
val SurfaceDarkNavy = Color(0xFF111D36)
val SurfaceCardNavy = Color(0xFF182645)
val SurfaceCardBorder = Color(0xFF283B63)

val ElectricBlue = Color(0xFF2563EB)
val VividCyan = Color(0xFF06B6D4)
val NeonSkyBlue = Color(0xFF38BDF8)
val AccentBlueLight = Color(0xFF60A5FA)
val DeepIndigo = Color(0xFF4338CA)

val AccentSuccess = Color(0xFF10B981)
val AccentWarning = Color(0xFFF59E0B)
val AccentError = Color(0xFFEF4444)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Gradients
val PrimaryButtonGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF2563EB), Color(0xFF06B6D4))
)

val GlowCardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF182645), Color(0xFF0F1B33))
)

val HeaderGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF0E1A36), Color(0xFF070B14))
)
