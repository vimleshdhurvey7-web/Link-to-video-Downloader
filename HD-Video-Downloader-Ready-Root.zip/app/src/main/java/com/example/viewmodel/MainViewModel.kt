package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppSettings
import com.example.data.SettingsRepository
import com.example.data.local.DownloadDatabase
import com.example.data.local.DownloadEntity
import com.example.downloader.ActiveDownloadState
import com.example.downloader.DownloadEngine
import com.example.downloader.UrlValidator
import com.example.model.VideoAnalysis
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab {
    DOWNLOADER,
    DOWNLOADS,
    PLAYER,
    SETTINGS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = DownloadDatabase.getInstance(application)
    private val downloadDao = database.downloadDao()
    private val settingsRepo = SettingsRepository(application)
    private val urlValidator = UrlValidator()
    private val downloadEngine = DownloadEngine(application, downloadDao, viewModelScope)

    val downloads: StateFlow<List<DownloadEntity>> = downloadDao.getAllDownloads()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings> = settingsRepo.settings
    val activeDownload: StateFlow<ActiveDownloadState?> = downloadEngine.activeDownload

    private val _currentTab = MutableStateFlow(AppTab.DOWNLOADER)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isValidating = MutableStateFlow(false)
    val isValidating: StateFlow<Boolean> = _isValidating.asStateFlow()

    private val _videoAnalysis = MutableStateFlow<VideoAnalysis?>(null)
    val videoAnalysis: StateFlow<VideoAnalysis?> = _videoAnalysis.asStateFlow()

    private val _selectedPlayerVideo = MutableStateFlow<DownloadEntity?>(null)
    val selectedPlayerVideo: StateFlow<DownloadEntity?> = _selectedPlayerVideo.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun onUrlChanged(newUrl: String) {
        _urlInput.value = newUrl
        if (newUrl.isBlank()) {
            _videoAnalysis.value = null
        }
    }

    fun clearUrl() {
        _urlInput.value = ""
        _videoAnalysis.value = null
    }

    fun analyzeCurrentUrl() {
        val url = _urlInput.value.trim()
        if (url.isBlank()) return

        viewModelScope.launch {
            _isValidating.value = true
            try {
                val analysis = urlValidator.analyzeUrl(url)
                _videoAnalysis.value = analysis
            } catch (e: Exception) {
                _toastMessage.value = "Failed to analyze URL: ${e.message}"
            } finally {
                _isValidating.value = false
            }
        }
    }

    fun startDownload() {
        val analysis = _videoAnalysis.value ?: return
        if (!analysis.isValid || !analysis.isDownloadAuthorized) {
            return
        }

        viewModelScope.launch {
            try {
                downloadEngine.startDownload(
                    analysis = analysis,
                    wifiOnly = settings.value.wifiOnly,
                    showNotifications = settings.value.notifications
                )
                _toastMessage.value = "Download initiated for ${analysis.title}"
            } catch (e: Exception) {
                _toastMessage.value = "Download failed to start: ${e.message}"
            }
        }
    }

    fun cancelActiveDownload(entityId: Long, dmId: Long) {
        viewModelScope.launch {
            downloadEngine.cancelDownload(entityId, dmId)
            _toastMessage.value = "Download canceled"
        }
    }

    fun deleteDownload(entity: DownloadEntity) {
        viewModelScope.launch {
            downloadEngine.deleteDownload(entity)
            if (_selectedPlayerVideo.value?.id == entity.id) {
                _selectedPlayerVideo.value = null
            }
            _toastMessage.value = "Download removed"
        }
    }

    fun playVideo(entity: DownloadEntity) {
        _selectedPlayerVideo.value = entity
        _currentTab.value = AppTab.PLAYER
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun setWifiOnly(enabled: Boolean) {
        settingsRepo.setWifiOnly(enabled)
    }

    fun setNotifications(enabled: Boolean) {
        settingsRepo.setNotifications(enabled)
    }

    fun setTheme(theme: String) {
        settingsRepo.setTheme(theme)
    }

    fun setLanguage(lang: String) {
        settingsRepo.setLanguage(lang)
    }

    fun selectSampleUrl(url: String) {
        _urlInput.value = url
        analyzeCurrentUrl()
    }
}
