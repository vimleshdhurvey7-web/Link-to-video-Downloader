package com.example

import com.example.ui.components.formatBytes
import com.example.ui.components.formatDuration
import com.example.ui.components.formatSpeed
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testFormatBytes() {
    assertEquals("0 B", formatBytes(0))
    assertEquals("1.0 KB", formatBytes(1024))
    assertEquals("1.0 MB", formatBytes(1024 * 1024))
    assertEquals("1.50 GB", formatBytes((1.5 * 1024 * 1024 * 1024).toLong()))
  }

  @Test
  fun testFormatSpeed() {
    assertEquals("0 KB/s", formatSpeed(0))
    assertEquals("500 KB/s", formatSpeed(500 * 1024))
    assertEquals("2.5 MB/s", formatSpeed((2.5 * 1024 * 1024).toLong()))
  }

  @Test
  fun testFormatDuration() {
    assertEquals("00:00", formatDuration(0))
    assertEquals("01:30", formatDuration(90 * 1000))
    assertEquals("01:05:20", formatDuration((3600 + 320) * 1000))
  }
}
